import asyncio
import logging

from aiogram import Bot, Dispatcher

from config import BOT_TOKEN
from database.database import init_db
from database.seed import seed_categories
from handlers.start import router
from handlers.mode import router as mode_router
from handlers.profile import router as profile_router
from handlers.client import router as client_router
from handlers.categories import router as categories_router
from handlers.client.jobs import router as jobs_router
from handlers.freelancer import router as freelancer_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)


async def main():

    logging.info("🚀 Запускаем FreelanceJob...")
    # Создаём таблицы
    await init_db()
    await seed_categories()
    logging.info("База данных готова")

    bot = Bot(
        token=BOT_TOKEN
    )

    dp = Dispatcher()

    # Подключаем handlers
    dp.include_router(router)
    dp.include_router(mode_router)
    dp.include_router(profile_router)
    dp.include_router(client_router)
    dp.include_router(categories_router)
    dp.include_router(jobs_router)
    dp.include_router(freelancer_router)

    logging.info("🤖 Бот успешно запущен!")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())